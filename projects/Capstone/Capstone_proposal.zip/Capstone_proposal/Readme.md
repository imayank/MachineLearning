The folder contains the foloowing files:

test_maze_## : three sample test maze inputs to evaluate the solution.

maze_## : Visualization corresponding to the test_maze_##

Proposal.pdf : Capstone project proposal